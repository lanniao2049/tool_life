--SQL server��������
go

--�������ݿ�
create database student
	on primary(name=student_data,
	filename='c:\data\student.mdf',
	size=3mb,
	maxsize=50mb,
	filegrowth=25%)
	log on(name=student_log,
	filename='c:\data\student.ldf',
	size=1mb,
	maxsize=50mb,
	filegrowth=1mb);

go

use student;
go

--ɾ�����ݿ�
drop database student;
go


--��ѯ����

use AdventureWorks2008;
go

select * from Person.ContactType;

select c.Name,c.ModifiedDate from Person.ContactType c;

select top 100 * from Person.Address;

select top(100) * from Person.Address;


select * from Person.Address;

select * from Person.StateProvince;

select * from Person.CountryRegion;


select cr.Name as countryName,sp.Name provinceName, a.* from Person.Address a
inner join Person.StateProvince sp
on sp.StateProvinceID=a.StateProvinceID
inner join Person.CountryRegion cr
on cr.CountryRegionCode=sp.CountryRegionCode
where a.City='Bothell';

go

--�������

insert into Person.ContactType(Name,ModifiedDate) values('Test1','2021-01-01');

insert into Person.ContactType values('Test2','2021-01-02');

insert into Person.ContactType(ModifiedDate,Name) values('2021-01-03','Test3');

go

---��������
insert into Person.ContactType(Name,ModifiedDate)
select at.Name,at.ModifiedDate from Person.AddressType at;

go
---��������top
insert into Person.ContactType(Name,ModifiedDate)
select top(3) sp.Name,sp.ModifiedDate from Person.StateProvince sp;

go
--����
insert top(3) into Person.ContactType(Name,ModifiedDate)
select  sp.Name,sp.ModifiedDate from Person.StateProvince sp;
go

--����
update Person.ContactType
set Name='--'+Name
where ContactTypeID>20;
go

--���� �������

update Person.ContactType
set Name=at.rowguid
from Person.ContactType ct
inner join Person.AddressType at
on ct.Name='--'+at.Name
go

--���� top
update top(3) Person.ContactType
set Name=sp.StateProvinceID
from Person.ContactType ct
inner join Person.StateProvince sp
on ct.Name='--'+sp.Name;

go

--ɾ������
delete from Person.ContactType where ContactTypeID>20;

delete top(2) from Person.ContactType where ContactTypeID>20;

delete from Person.ContactType
from Person.ContactType ct
inner join Person.StateProvince sp
on ct.Name=sp.Name;
